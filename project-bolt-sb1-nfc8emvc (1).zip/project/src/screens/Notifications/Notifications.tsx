import React from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeftIcon, HeartIcon, MessageCircleIcon, UserPlusIcon, BellIcon } from "lucide-react";
import { Avatar, AvatarFallback } from "../../components/ui/avatar";

export const Notifications = (): JSX.Element => {
  const navigate = useNavigate();

  const handleBack = () => {
    navigate("/");
  };

  const notifications = [
    {
      id: 1,
      type: "like",
      user: "Monkey D. Luffy",
      avatar: "ML",
      action: "liked your post",
      content: "Breathtaking Mountain Landscape",
      time: "2 minutes ago",
      read: false,
    },
    {
      id: 2,
      type: "comment",
      user: "Roronoa Zoro",
      avatar: "RZ",
      action: "commented on your post",
      content: "Amazing shot! The composition is perfect.",
      time: "15 minutes ago",
      read: false,
    },
    {
      id: 3,
      type: "follow",
      user: "Nami",
      avatar: "N",
      action: "started following you",
      content: "",
      time: "1 hour ago",
      read: true,
    },
    {
      id: 4,
      type: "like",
      user: "Sanji",
      avatar: "S",
      action: "liked your post",
      content: "Gourmet Food Photography",
      time: "2 hours ago",
      read: true,
    },
    {
      id: 5,
      type: "comment",
      user: "Nico Robin",
      avatar: "NR",
      action: "commented on your post",
      content: "This reminds me of the ancient ruins we explored!",
      time: "3 hours ago",
      read: true,
    },
    {
      id: 6,
      type: "follow",
      user: "Tony Tony Chopper",
      avatar: "TC",
      action: "started following you",
      content: "",
      time: "1 day ago",
      read: true,
    },
  ];

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "like":
        return <HeartIcon className="text-red-500" size={20} />;
      case "comment":
        return <MessageCircleIcon className="text-blue-500" size={20} />;
      case "follow":
        return <UserPlusIcon className="text-green-500" size={20} />;
      default:
        return <BellIcon className="text-gray-500" size={20} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <button
              onClick={handleBack}
              className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeftIcon size={20} />
              <span className="font-medium">Back to Home</span>
            </button>
            
            <h1 className="text-2xl font-bold text-gray-900">Notifications</h1>
            
            <button className="text-blue-600 hover:text-blue-800 font-medium">
              Mark all as read
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-4">
          {notifications.map((notification) => (
            <div
              key={notification.id}
              className={`bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow cursor-pointer ${
                !notification.read ? "border-l-4 border-blue-500" : ""
              }`}
            >
              <div className="flex items-start space-x-4">
                <Avatar className="w-12 h-12 bg-gradient-to-r from-orange-400 to-red-500">
                  <AvatarFallback className="text-white font-semibold">
                    {notification.avatar}
                  </AvatarFallback>
                </Avatar>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2 mb-1">
                    {getNotificationIcon(notification.type)}
                    <p className="text-sm text-gray-900">
                      <span className="font-semibold">{notification.user}</span>{" "}
                      {notification.action}
                    </p>
                    {!notification.read && (
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    )}
                  </div>
                  
                  {notification.content && (
                    <p className="text-sm text-gray-600 mb-2">
                      "{notification.content}"
                    </p>
                  )}
                  
                  <p className="text-xs text-gray-500">{notification.time}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};