import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeftIcon, SendIcon, SearchIcon } from "lucide-react";
import { Avatar, AvatarFallback } from "../../components/ui/avatar";

export const Messages = (): JSX.Element => {
  const navigate = useNavigate();
  const [selectedChat, setSelectedChat] = useState(0);
  const [newMessage, setNewMessage] = useState("");

  const handleBack = () => {
    navigate("/");
  };

  const chats = [
    {
      id: 0,
      name: "Monkey D. Luffy",
      avatar: "ML",
      lastMessage: "Let's go on an adventure! 🏴‍☠️",
      time: "2m ago",
      unread: 3,
      online: true,
    },
    {
      id: 1,
      name: "Roronoa Zoro",
      avatar: "RZ",
      lastMessage: "I got lost again... 😅",
      time: "15m ago",
      unread: 1,
      online: true,
    },
    {
      id: 2,
      name: "Nami",
      avatar: "N",
      lastMessage: "Check out this treasure map!",
      time: "1h ago",
      unread: 0,
      online: false,
    },
    {
      id: 3,
      name: "Sanji",
      avatar: "S",
      lastMessage: "I made your favorite dish! 🍳",
      time: "2h ago",
      unread: 0,
      online: true,
    },
    {
      id: 4,
      name: "Nico Robin",
      avatar: "NR",
      lastMessage: "Found some interesting history books",
      time: "1d ago",
      unread: 0,
      online: false,
    },
  ];

  const messages = [
    {
      id: 1,
      sender: "Monkey D. Luffy",
      content: "Hey! Want to join our crew for the next adventure?",
      time: "10:30 AM",
      isMe: false,
    },
    {
      id: 2,
      sender: "Me",
      content: "That sounds amazing! Where are we heading?",
      time: "10:32 AM",
      isMe: true,
    },
    {
      id: 3,
      sender: "Monkey D. Luffy",
      content: "To the Grand Line! We're looking for the One Piece! 🏴‍☠️",
      time: "10:33 AM",
      isMe: false,
    },
    {
      id: 4,
      sender: "Me",
      content: "Count me in! When do we set sail?",
      time: "10:35 AM",
      isMe: true,
    },
    {
      id: 5,
      sender: "Monkey D. Luffy",
      content: "Let's go on an adventure! 🏴‍☠️",
      time: "10:36 AM",
      isMe: false,
    },
  ];

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (newMessage.trim()) {
      console.log("Sending message:", newMessage);
      setNewMessage("");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <button
              onClick={handleBack}
              className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeftIcon size={20} />
              <span className="font-medium">Back to Home</span>
            </button>
            
            <h1 className="text-2xl font-bold text-gray-900">Messages</h1>
            
            <div className="w-20"></div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden h-[600px] flex">
          {/* Chat List */}
          <div className="w-1/3 border-r border-gray-200">
            <div className="p-4 border-b border-gray-200">
              <div className="relative">
                <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <input
                  type="text"
                  placeholder="Search conversations..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-full focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
            
            <div className="overflow-y-auto h-full">
              {chats.map((chat) => (
                <div
                  key={chat.id}
                  onClick={() => setSelectedChat(chat.id)}
                  className={`p-4 cursor-pointer hover:bg-gray-50 transition-colors ${
                    selectedChat === chat.id ? "bg-blue-50 border-r-2 border-blue-500" : ""
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <div className="relative">
                      <Avatar className="w-12 h-12 bg-gradient-to-r from-orange-400 to-red-500">
                        <AvatarFallback className="text-white font-semibold">
                          {chat.avatar}
                        </AvatarFallback>
                      </Avatar>
                      {chat.online && (
                        <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                      )}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h3 className="font-semibold text-gray-900 truncate">{chat.name}</h3>
                        <span className="text-xs text-gray-500">{chat.time}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <p className="text-sm text-gray-600 truncate">{chat.lastMessage}</p>
                        {chat.unread > 0 && (
                          <span className="bg-blue-500 text-white text-xs rounded-full px-2 py-1 min-w-[20px] text-center">
                            {chat.unread}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Chat Messages */}
          <div className="flex-1 flex flex-col">
            {/* Chat Header */}
            <div className="p-4 border-b border-gray-200 bg-gray-50">
              <div className="flex items-center space-x-3">
                <Avatar className="w-10 h-10 bg-gradient-to-r from-orange-400 to-red-500">
                  <AvatarFallback className="text-white font-semibold">
                    {chats[selectedChat].avatar}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-semibold text-gray-900">{chats[selectedChat].name}</h3>
                  <p className="text-sm text-green-500">Online</p>
                </div>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.isMe ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-xs lg:max-w-md px-4 py-2 rounded-2xl ${
                      message.isMe
                        ? "bg-blue-500 text-white"
                        : "bg-gray-200 text-gray-900"
                    }`}
                  >
                    <p className="text-sm">{message.content}</p>
                    <p
                      className={`text-xs mt-1 ${
                        message.isMe ? "text-blue-100" : "text-gray-500"
                      }`}
                    >
                      {message.time}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Message Input */}
            <div className="p-4 border-t border-gray-200">
              <form onSubmit={handleSendMessage} className="flex space-x-2">
                <input
                  type="text"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder="Type a message..."
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-full focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <button
                  type="submit"
                  className="bg-blue-500 text-white p-2 rounded-full hover:bg-blue-600 transition-colors"
                >
                  <SendIcon size={20} />
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};