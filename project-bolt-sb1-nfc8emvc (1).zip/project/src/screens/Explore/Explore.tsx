import React from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeftIcon, TrendingUpIcon, HashIcon, UsersIcon } from "lucide-react";

export const Explore = (): JSX.Element => {
  const navigate = useNavigate();

  const handleBack = () => {
    navigate("/");
  };

  const trendingTopics = [
    { name: "One Piece", posts: "2.5M", color: "bg-red-500" },
    { name: "Anime Art", posts: "1.8M", color: "bg-blue-500" },
    { name: "Manga", posts: "1.2M", color: "bg-green-500" },
    { name: "Digital Art", posts: "950K", color: "bg-purple-500" },
    { name: "Character Design", posts: "780K", color: "bg-orange-500" },
    { name: "Fan Art", posts: "650K", color: "bg-pink-500" },
  ];

  const categories = [
    { name: "Photography", image: "https://images.pexels.com/photos/1704120/pexels-photo-1704120.jpeg" },
    { name: "Art & Design", image: "https://images.unsplash.com/photo-1545239351-1141bd82e8a6" },
    { name: "Food", image: "https://images.pexels.com/photos/459225/pexels-photo-459225.jpeg" },
    { name: "Travel", image: "https://images.unsplash.com/photo-1496483648148-47c686dc86a8" },
    { name: "Fashion", image: "https://images.pexels.com/photos/1323550/pexels-photo-1323550.jpeg" },
    { name: "Technology", image: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <button
              onClick={handleBack}
              className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeftIcon size={20} />
              <span className="font-medium">Back to Home</span>
            </button>
            
            <h1 className="text-2xl font-bold text-gray-900">Explore</h1>
            
            <div className="w-20"></div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Trending Section */}
        <div className="mb-12">
          <div className="flex items-center space-x-2 mb-6">
            <TrendingUpIcon className="text-red-500" size={24} />
            <h2 className="text-2xl font-bold text-gray-900">Trending Now</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {trendingTopics.map((topic, index) => (
              <div
                key={index}
                className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow cursor-pointer"
              >
                <div className="flex items-center space-x-4">
                  <div className={`w-12 h-12 ${topic.color} rounded-full flex items-center justify-center`}>
                    <HashIcon className="text-white" size={20} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{topic.name}</h3>
                    <p className="text-gray-500">{topic.posts} posts</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Categories Section */}
        <div>
          <div className="flex items-center space-x-2 mb-6">
            <UsersIcon className="text-blue-500" size={24} />
            <h2 className="text-2xl font-bold text-gray-900">Popular Categories</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((category, index) => (
              <div
                key={index}
                className="relative group cursor-pointer overflow-hidden rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
              >
                <img
                  src={category.image}
                  alt={category.name}
                  className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black bg-opacity-40 group-hover:bg-opacity-50 transition-all duration-300 flex items-center justify-center">
                  <h3 className="text-white text-xl font-bold">{category.name}</h3>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};