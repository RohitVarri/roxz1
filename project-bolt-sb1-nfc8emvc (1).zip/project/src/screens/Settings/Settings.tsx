import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { 
  ArrowLeftIcon, 
  UserIcon, 
  BellIcon, 
  ShieldIcon, 
  PaletteIcon, 
  HelpCircleIcon,
  LogOutIcon,
  ToggleLeftIcon,
  ToggleRightIcon
} from "lucide-react";
import { Avatar, AvatarFallback } from "../../components/ui/avatar";

export const Settings = (): JSX.Element => {
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState(true);
  const [darkMode, setDarkMode] = useState(false);
  const [privateAccount, setPrivateAccount] = useState(false);

  const handleBack = () => {
    navigate("/");
  };

  const settingSections = [
    {
      title: "Account",
      icon: <UserIcon size={20} />,
      items: [
        { name: "Edit Profile", description: "Update your profile information" },
        { name: "Change Password", description: "Update your account password" },
        { name: "Email Preferences", description: "Manage email notifications" },
      ]
    },
    {
      title: "Privacy & Security",
      icon: <ShieldIcon size={20} />,
      items: [
        { name: "Privacy Settings", description: "Control who can see your content" },
        { name: "Blocked Users", description: "Manage blocked accounts" },
        { name: "Data & Privacy", description: "Download or delete your data" },
      ]
    },
    {
      title: "Appearance",
      icon: <PaletteIcon size={20} />,
      items: [
        { name: "Theme", description: "Choose your preferred theme" },
        { name: "Language", description: "Select your language" },
        { name: "Display Settings", description: "Customize your display" },
      ]
    },
    {
      title: "Support",
      icon: <HelpCircleIcon size={20} />,
      items: [
        { name: "Help Center", description: "Get help and support" },
        { name: "Report a Problem", description: "Report bugs or issues" },
        { name: "Terms of Service", description: "Read our terms" },
        { name: "Privacy Policy", description: "Read our privacy policy" },
      ]
    }
  ];

  const ToggleSwitch = ({ enabled, onToggle }: { enabled: boolean; onToggle: () => void }) => (
    <button
      onClick={onToggle}
      className={`p-1 rounded-full transition-colors ${
        enabled ? "text-blue-500" : "text-gray-400"
      }`}
    >
      {enabled ? <ToggleRightIcon size={24} /> : <ToggleLeftIcon size={24} />}
    </button>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <button
              onClick={handleBack}
              className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeftIcon size={20} />
              <span className="font-medium">Back to Home</span>
            </button>
            
            <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
            
            <div className="w-20"></div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Profile Section */}
        <div className="bg-white rounded-2xl p-8 shadow-lg mb-8">
          <div className="flex items-center space-x-6">
            <Avatar className="w-20 h-20 bg-gradient-to-r from-orange-400 to-red-500">
              <AvatarFallback className="text-white text-2xl font-bold">
                R
              </AvatarFallback>
            </Avatar>
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Roronoa Zoro</h2>
              <p className="text-gray-600">@zoro_swordsman</p>
              <p className="text-sm text-gray-500 mt-1">Joined December 2024</p>
            </div>
          </div>
        </div>

        {/* Quick Settings */}
        <div className="bg-white rounded-2xl p-8 shadow-lg mb-8">
          <h3 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
            <BellIcon className="mr-2" size={24} />
            Quick Settings
          </h3>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between py-3">
              <div>
                <h4 className="font-medium text-gray-900">Push Notifications</h4>
                <p className="text-sm text-gray-500">Receive notifications about your activity</p>
              </div>
              <ToggleSwitch 
                enabled={notifications} 
                onToggle={() => setNotifications(!notifications)} 
              />
            </div>
            
            <div className="flex items-center justify-between py-3">
              <div>
                <h4 className="font-medium text-gray-900">Dark Mode</h4>
                <p className="text-sm text-gray-500">Switch to dark theme</p>
              </div>
              <ToggleSwitch 
                enabled={darkMode} 
                onToggle={() => setDarkMode(!darkMode)} 
              />
            </div>
            
            <div className="flex items-center justify-between py-3">
              <div>
                <h4 className="font-medium text-gray-900">Private Account</h4>
                <p className="text-sm text-gray-500">Only followers can see your posts</p>
              </div>
              <ToggleSwitch 
                enabled={privateAccount} 
                onToggle={() => setPrivateAccount(!privateAccount)} 
              />
            </div>
          </div>
        </div>

        {/* Settings Sections */}
        <div className="space-y-6">
          {settingSections.map((section, sectionIndex) => (
            <div key={sectionIndex} className="bg-white rounded-2xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
                {section.icon}
                <span className="ml-2">{section.title}</span>
              </h3>
              
              <div className="space-y-2">
                {section.items.map((item, itemIndex) => (
                  <button
                    key={itemIndex}
                    className="w-full text-left p-4 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <h4 className="font-medium text-gray-900">{item.name}</h4>
                    <p className="text-sm text-gray-500 mt-1">{item.description}</p>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Logout Section */}
        <div className="bg-white rounded-2xl p-8 shadow-lg mt-8">
          <button className="w-full flex items-center justify-center space-x-2 text-red-600 hover:text-red-800 font-medium py-3">
            <LogOutIcon size={20} />
            <span>Log Out</span>
          </button>
        </div>
      </div>
    </div>
  );
};