import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  BellIcon,
  CompassIcon,
  HomeIcon,
  MessageCircleIcon,
  PlusIcon,
  SearchIcon,
  SettingsIcon,
  UploadIcon,
  ImageIcon,
  TagIcon,
  SaveIcon,
  XIcon,
  CameraIcon,
  FileIcon,
  LinkIcon,
} from "lucide-react";
import { Avatar, AvatarFallback } from "../../components/ui/avatar";
import { Input } from "../../components/ui/input";
import { ScrollArea, ScrollBar } from "../../components/ui/scroll-area";

export const CreatePost = (): JSX.Element => {
  const navigate = useNavigate();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [tags, setTags] = useState("");
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const [uploadMethod, setUploadMethod] = useState<'upload' | 'url' | null>(null);
  const [imageUrl, setImageUrl] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  // Navigation handlers
  const handleNavigation = (section: string) => {
    console.log(`Navigating to ${section}`);
    switch (section) {
      case 'home':
        navigate('/home');
        break;
      case 'explore':
        navigate('/explore');
        break;
      case 'create':
        navigate('/create');
        break;
      case 'notifications':
        navigate('/notifications');
        break;
      case 'messages':
        navigate('/messages');
        break;
      case 'settings':
        navigate('/settings');
        break;
      default:
        break;
    }
  };

  // Navigation icons data with handlers
  const navigationIcons = [
    { 
      icon: <HomeIcon size={28} />, 
      alt: "Home", 
      top: "top-0",
      onClick: () => handleNavigation('home'),
      active: false
    },
    { 
      icon: <CompassIcon size={28} />, 
      alt: "Explore", 
      top: "top-[126px]",
      onClick: () => handleNavigation('explore'),
      active: false
    },
    { 
      icon: <PlusIcon size={24} />, 
      alt: "Create Post", 
      top: "top-[252px]",
      onClick: () => handleNavigation('create'),
      active: true
    },
    { 
      icon: <BellIcon size={28} />, 
      alt: "Notifications", 
      top: "top-[363px]",
      onClick: () => handleNavigation('notifications'),
      active: false
    },
    {
      icon: <MessageCircleIcon size={28} />,
      alt: "Messages",
      top: "top-[484px]",
      onClick: () => handleNavigation('messages'),
      active: false
    },
    { 
      icon: <SettingsIcon size={24} />, 
      alt: "Settings", 
      top: "top-[765px]",
      onClick: () => handleNavigation('settings'),
      active: false
    },
  ];

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      setUploadMethod(null);
    }
  };

  const handleUploadFile = () => {
    if (selectedFile) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setSelectedImage(e.target?.result as string);
        setSelectedFile(null);
      };
      reader.readAsDataURL(selectedFile);
    }
  };

  const handleUrlSubmit = () => {
    if (imageUrl.trim()) {
      setSelectedImage(imageUrl);
      setImageUrl("");
      setUploadMethod(null);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      setSelectedFile(file);
      setUploadMethod(null);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Creating post:", { title, description, tags, selectedImage });
    alert("Post created successfully!");
    navigate("/");
  };

  const removeImage = () => {
    setSelectedImage(null);
    setSelectedFile(null);
    setUploadMethod(null);
  };

  return (
    <div className="bg-white flex flex-row justify-center w-full">
      <div className="bg-white overflow-x-hidden w-[1440px] h-[1024px] relative">
        {/* Search Bar and Profile */}
        <div className="fixed w-[1353px] h-20 top-[38px] left-[94px] z-10 bg-white">
          <div className="w-[1357px] h-20 relative">
            <Avatar className="absolute w-[78px] h-[78px] top-0 left-[1213px] bg-[#c590f3] rounded-[39px] cursor-pointer hover:opacity-80 transition-opacity">
              <AvatarFallback className="text-[40px] font-medium">
                R
              </AvatarFallback>
            </Avatar>

            <div className="absolute w-[1125px] h-[72px] top-2 left-[55px] bg-[#d9d9d9] rounded-[15px] shadow-[inset_0px_4px_4px_#00000040] flex items-center px-6">
              <SearchIcon className="w-[35px] h-[39px] mr-4" />
              <Input
                className="border-none bg-transparent shadow-none text-[25px] font-medium font-['Inter',Helvetica] h-full placeholder:text-black focus-visible:ring-0"
                placeholder="Search"
              />
            </div>
          </div>
        </div>

        {/* Main Content Area with Proper Scrolling */}
        <ScrollArea className="fixed w-[1246px] h-[906px] top-[118px] left-[168px]">
          <div className="w-full min-h-[1200px] px-8 py-8">
            <div className="max-w-4xl mx-auto">
              <form onSubmit={handleSubmit} className="space-y-8">
                {/* Header */}
                <div className="text-center mb-8">
                  <h1 className="text-4xl font-bold text-gray-900 mb-2">Create New Post</h1>
                  <p className="text-gray-600">Share your amazing content with the world</p>
                </div>

                {/* Image Upload Section */}
                <div className="bg-white rounded-3xl p-8 shadow-xl border border-gray-100">
                  <h2 className="text-2xl font-semibold text-gray-900 mb-6 flex items-center">
                    <ImageIcon className="mr-3 text-blue-500" size={28} />
                    Upload Your Image
                  </h2>
                  
                  {!selectedImage ? (
                    <div className="space-y-6">
                      {/* Upload Methods */}
                      {!uploadMethod && !selectedFile && (
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                          <button
                            type="button"
                            onClick={() => setUploadMethod('upload')}
                            className="flex flex-col items-center p-6 border-2 border-dashed border-gray-300 rounded-xl hover:border-blue-400 hover:bg-blue-50 transition-all duration-200 group"
                          >
                            <UploadIcon className="text-gray-400 group-hover:text-blue-500 mb-3" size={32} />
                            <span className="font-medium text-gray-700 group-hover:text-blue-600">Upload File</span>
                            <span className="text-sm text-gray-500">PNG, JPG, GIF</span>
                          </button>
                          
                          <button
                            type="button"
                            onClick={() => setUploadMethod('url')}
                            className="flex flex-col items-center p-6 border-2 border-dashed border-gray-300 rounded-xl hover:border-green-400 hover:bg-green-50 transition-all duration-200 group"
                          >
                            <LinkIcon className="text-gray-400 group-hover:text-green-500 mb-3" size={32} />
                            <span className="font-medium text-gray-700 group-hover:text-green-600">From URL</span>
                            <span className="text-sm text-gray-500">Paste image link</span>
                          </button>
                          
                          <label className="flex flex-col items-center p-6 border-2 border-dashed border-gray-300 rounded-xl hover:border-purple-400 hover:bg-purple-50 transition-all duration-200 group cursor-pointer">
                            <CameraIcon className="text-gray-400 group-hover:text-purple-500 mb-3" size={32} />
                            <span className="font-medium text-gray-700 group-hover:text-purple-600">Take Photo</span>
                            <span className="text-sm text-gray-500">Use camera</span>
                            <input
                              type="file"
                              accept="image/*"
                              capture="environment"
                              onChange={handleFileSelect}
                              className="hidden"
                            />
                          </label>
                        </div>
                      )}

                      {/* File Upload */}
                      {uploadMethod === 'upload' && (
                        <div className="space-y-4">
                          <div
                            className={`border-2 border-dashed rounded-xl p-12 text-center transition-all duration-200 ${
                              dragActive 
                                ? "border-blue-500 bg-blue-50" 
                                : "border-gray-300 hover:border-blue-400 hover:bg-gray-50"
                            }`}
                            onDragEnter={handleDrag}
                            onDragLeave={handleDrag}
                            onDragOver={handleDrag}
                            onDrop={handleDrop}
                          >
                            <div className="space-y-4">
                              <UploadIcon className="mx-auto text-gray-400" size={64} />
                              <div>
                                <label htmlFor="image-upload" className="cursor-pointer">
                                  <span className="text-2xl font-semibold text-blue-600 hover:text-blue-800">
                                    Click to select file
                                  </span>
                                  <span className="text-xl text-gray-500"> or drag and drop</span>
                                </label>
                                <input
                                  id="image-upload"
                                  type="file"
                                  accept="image/*"
                                  onChange={handleFileSelect}
                                  className="hidden"
                                />
                              </div>
                              <p className="text-gray-500">PNG, JPG, GIF up to 10MB</p>
                            </div>
                          </div>
                          <div className="flex justify-center space-x-3">
                            <button
                              type="button"
                              onClick={() => setUploadMethod(null)}
                              className="px-4 py-2 text-gray-600 hover:text-gray-800 border border-gray-300 rounded-lg"
                            >
                              Cancel
                            </button>
                          </div>
                        </div>
                      )}

                      {/* Selected File Preview */}
                      {selectedFile && (
                        <div className="space-y-4">
                          <div className="p-6 bg-blue-50 border border-blue-200 rounded-xl">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-3">
                                <FileIcon className="text-blue-500" size={24} />
                                <div>
                                  <p className="font-medium text-gray-900">{selectedFile.name}</p>
                                  <p className="text-sm text-gray-500">
                                    {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                                  </p>
                                </div>
                              </div>
                              <button
                                type="button"
                                onClick={() => setSelectedFile(null)}
                                className="text-red-500 hover:text-red-700"
                              >
                                <XIcon size={20} />
                              </button>
                            </div>
                          </div>
                          <div className="flex justify-center space-x-3">
                            <button
                              type="button"
                              onClick={() => setSelectedFile(null)}
                              className="px-6 py-3 text-gray-600 hover:text-gray-800 border border-gray-300 rounded-lg"
                            >
                              Cancel
                            </button>
                            <button
                              type="button"
                              onClick={handleUploadFile}
                              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
                            >
                              Upload Image
                            </button>
                          </div>
                        </div>
                      )}

                      {/* URL Upload */}
                      {uploadMethod === 'url' && (
                        <div className="space-y-4">
                          <div className="flex space-x-3">
                            <input
                              type="url"
                              value={imageUrl}
                              onChange={(e) => setImageUrl(e.target.value)}
                              placeholder="Paste image URL here..."
                              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg"
                            />
                          </div>
                          <div className="flex justify-center space-x-3">
                            <button
                              type="button"
                              onClick={() => setUploadMethod(null)}
                              className="px-6 py-3 text-gray-600 hover:text-gray-800 border border-gray-300 rounded-lg"
                            >
                              Cancel
                            </button>
                            <button
                              type="button"
                              onClick={handleUrlSubmit}
                              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
                            >
                              Add Image
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="space-y-6">
                      <div className="relative group">
                        <img
                          src={selectedImage}
                          alt="Preview"
                          className="w-full max-h-96 object-cover rounded-xl shadow-lg"
                        />
                        <button
                          type="button"
                          onClick={removeImage}
                          className="absolute top-4 right-4 p-2 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-600"
                        >
                          <XIcon size={20} />
                        </button>
                      </div>
                      <div className="text-center">
                        <p className="text-green-600 font-medium mb-2">✓ Image uploaded successfully!</p>
                        <button
                          type="button"
                          onClick={removeImage}
                          className="text-red-600 hover:text-red-800 font-medium"
                        >
                          Remove Image
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* Post Details Section */}
                <div className="bg-white rounded-3xl p-8 shadow-xl border border-gray-100 space-y-6">
                  <h2 className="text-2xl font-semibold text-gray-900 flex items-center">
                    <FileIcon className="mr-3 text-green-500" size={28} />
                    Post Details
                  </h2>
                  
                  <div className="space-y-6">
                    <div>
                      <label htmlFor="title" className="block text-lg font-medium text-gray-700 mb-3">
                        Title *
                      </label>
                      <input
                        type="text"
                        id="title"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        className="w-full px-6 py-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg"
                        placeholder="Give your post a catchy title..."
                        required
                      />
                    </div>

                    <div>
                      <label htmlFor="description" className="block text-lg font-medium text-gray-700 mb-3">
                        Description
                      </label>
                      <textarea
                        id="description"
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        rows={5}
                        className="w-full px-6 py-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg resize-none"
                        placeholder="Tell people more about your post..."
                      />
                    </div>

                    <div>
                      <label htmlFor="tags" className="block text-lg font-medium text-gray-700 mb-3 flex items-center">
                        <TagIcon className="mr-2 text-purple-500" size={20} />
                        Tags
                      </label>
                      <input
                        type="text"
                        id="tags"
                        value={tags}
                        onChange={(e) => setTags(e.target.value)}
                        className="w-full px-6 py-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg"
                        placeholder="Add tags separated by commas (e.g., onepiece, anime, art)"
                      />
                      <p className="text-gray-500 mt-2 text-sm">
                        Tags help people discover your content
                      </p>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex justify-center space-x-4 pb-8">
                  <button
                    type="button"
                    onClick={() => navigate("/")}
                    className="px-8 py-4 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors font-medium text-lg"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex items-center space-x-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-4 rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all duration-200 font-medium text-lg shadow-lg hover:shadow-xl"
                  >
                    <SaveIcon size={20} />
                    <span>Publish Post</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
          <ScrollBar
            orientation="vertical"
            className="w-6 bg-[#d9d9d9] rounded-[10px_10px_30px_0px]"
          />
        </ScrollArea>

        {/* Sidebar with One Piece logo and functional navigation */}
        <div className="fixed w-[116px] h-[1024px] top-0 left-0 bg-[#a8d2ec] flex flex-col items-center z-20">
          {/* One Piece Logo */}
          <div 
            className="w-[92px] h-[92px] mt-9 cursor-pointer hover:opacity-80 transition-opacity flex items-center justify-center bg-white rounded-full shadow-lg"
            onClick={() => handleNavigation('home')}
          >
            <img
              className="w-[80px] h-[80px] object-contain"
              alt="One Piece Logo"
              src="https://images.pexels.com/photos/8728380/pexels-photo-8728380.png?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
            />
          </div>

          <div className="relative w-[68px] h-[815px] mt-[74px]">
            {navigationIcons.map((item, index) => (
              <div
                key={`nav-icon-${index}`}
                className={`absolute w-[65px] h-[65px] ${item.top} left-0 flex items-center justify-center cursor-pointer rounded-lg transition-all duration-200 hover:scale-110 active:scale-95 ${
                  item.active 
                    ? "bg-white/30 shadow-lg" 
                    : "hover:bg-white/20"
                }`}
                onClick={item.onClick}
                title={item.alt}
              >
                {item.icon}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};