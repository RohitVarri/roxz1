import {
  BellIcon,
  CompassIcon,
  HomeIcon,
  MessageCircleIcon,
  PlusIcon,
  SearchIcon,
  SettingsIcon,
} from "lucide-react";
import React from "react";
import { useNavigate } from "react-router-dom";
import { Avatar, AvatarFallback } from "../../components/ui/avatar";
import { Input } from "../../components/ui/input";
import { ScrollArea, ScrollBar } from "../../components/ui/scroll-area";

export const Desktop = (): JSX.Element => {
  const navigate = useNavigate();

  // Navigation handlers
  const handleNavigation = (section: string) => {
    console.log(`Navigating to ${section}`);
    switch (section) {
      case 'home':
        navigate('/home');
        break;
      case 'explore':
        navigate('/explore');
        break;
      case 'create':
        navigate('/create');
        break;
      case 'notifications':
        navigate('/notifications');
        break;
      case 'messages':
        navigate('/messages');
        break;
      case 'settings':
        navigate('/settings');
        break;
      default:
        break;
    }
  };

  // Photo click handler - navigate to photo detail page
  const handlePhotoClick = (photoId: number) => {
    navigate(`/photo/${photoId}`);
  };

  // Navigation icons data with handlers
  const navigationIcons = [
    { 
      icon: <HomeIcon size={28} />, 
      alt: "Home", 
      top: "top-0",
      onClick: () => handleNavigation('home')
    },
    { 
      icon: <CompassIcon size={28} />, 
      alt: "Explore", 
      top: "top-[126px]",
      onClick: () => handleNavigation('explore')
    },
    { 
      icon: <PlusIcon size={24} />, 
      alt: "Create Post", 
      top: "top-[252px]",
      onClick: () => handleNavigation('create')
    },
    { 
      icon: <BellIcon size={28} />, 
      alt: "Notifications", 
      top: "top-[363px]",
      onClick: () => handleNavigation('notifications')
    },
    {
      icon: <MessageCircleIcon size={28} />,
      alt: "Messages",
      top: "top-[484px]",
      onClick: () => handleNavigation('messages')
    },
    { 
      icon: <SettingsIcon size={24} />, 
      alt: "Settings", 
      top: "top-[765px]",
      onClick: () => handleNavigation('settings')
    },
  ];

  // Gallery images data
  const galleryImages = [
    {
      src: "https://images.unsplash.com/photo-1526779259212-939e64788e3c?fm=jpg&q=60&w=3000",
      alt: "Nature landscape",
      top: "top-[18px]",
      left: "left-0",
      height: "h-[370px]",
    },
    {
      src: "https://images.pexels.com/photos/1704120/pexels-photo-1704120.jpeg",
      alt: "Architecture",
      top: "top-[18px]",
      left: "left-[302px]",
      height: "h-[270px]",
    },
    {
      src: "https://images.unsplash.com/photo-1545239351-1141bd82e8a6",
      alt: "Interior design",
      top: "top-[18px]",
      left: "left-[612px]",
      height: "h-[370px]",
    },
    {
      src: "https://images.pexels.com/photos/459225/pexels-photo-459225.jpeg",
      alt: "Food photography",
      top: "top-[18px]",
      left: "left-[928px]",
      height: "h-[270px]",
    },
    {
      src: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97",
      alt: "Technology",
      top: "top-[328px]",
      left: "left-[306px]",
      height: "h-[370px]",
    },
    {
      src: "https://images.pexels.com/photos/1323550/pexels-photo-1323550.jpeg",
      alt: "Fashion",
      top: "top-[328px]",
      left: "left-[932px]",
      height: "h-[370px]",
    },
    {
      src: "https://images.unsplash.com/photo-1496483648148-47c686dc86a8",
      alt: "Travel",
      top: "top-[424px]",
      left: "left-0",
      height: "h-[370px]",
    },
    {
      src: "https://images.unsplash.com/photo-1502082553048-f009c37129b9",
      alt: "Art",
      top: "top-[424px]",
      left: "left-[612px]",
      height: "h-[370px]",
    },
    {
      src: "https://images.unsplash.com/photo-1481277542470-605612bd2d61",
      alt: "Sports",
      top: "top-[844px]",
      left: "left-0",
      height: "h-[370px]",
    },
    {
      src: "https://images.pexels.com/photos/842711/pexels-photo-842711.jpeg",
      alt: "Animals",
      top: "top-[759px]",
      left: "left-[302px]",
      height: "h-[270px]",
    },
    {
      src: "https://images.unsplash.com/photo-1536895058696-a69b1e2483f1",
      alt: "Lifestyle",
      top: "top-[844px]",
      left: "left-[612px]",
      height: "h-[370px]",
    },
    {
      src: "https://images.unsplash.com/photo-1526244434298-88fcbcaaa67cf",
      alt: "Business",
      top: "top-[759px]",
      left: "left-[932px]",
      height: "h-[270px]",
    },
    {
      src: "https://images.unsplash.com/photo-1495563381401-ecfbcaaa67cf",
      alt: "Health",
      top: "top-[1090px]",
      left: "left-[302px]",
      height: "h-[370px]",
    },
    {
      src: "https://images.unsplash.com/photo-1606788075761-2bfa3c84e23c",
      alt: "Education",
      top: "top-[1090px]",
      left: "left-[932px]",
      height: "h-[370px]",
    },
    {
      src: "https://images.unsplash.com/photo-1542291026-7eec264c27ff",
      alt: "Music",
      top: "top-[1264px]",
      left: "left-0",
      height: "h-[370px]",
    },
    {
      src: "https://images.unsplash.com/photo-1472214103451-9374bd1c798e",
      alt: "Photography",
      top: "top-[1264px]",
      left: "left-[612px]",
      height: "h-[370px]",
    },
  ];

  return (
    <div className="bg-white flex flex-row justify-center w-full">
      <div className="bg-white overflow-x-hidden w-[1440px] h-[1024px] relative">
        {/* Search Bar and Profile */}
        <div className="fixed w-[1353px] h-20 top-[38px] left-[94px] z-10 bg-white">
          <div className="w-[1357px] h-20 relative">
            <Avatar className="absolute w-[78px] h-[78px] top-0 left-[1213px] bg-[#c590f3] rounded-[39px] cursor-pointer hover:opacity-80 transition-opacity">
              <AvatarFallback className="text-[40px] font-medium">
                R
              </AvatarFallback>
            </Avatar>

            <div className="absolute w-[1125px] h-[72px] top-2 left-[55px] bg-[#d9d9d9] rounded-[15px] shadow-[inset_0px_4px_4px_#00000040] flex items-center px-6">
              <SearchIcon className="w-[35px] h-[39px] mr-4" />
              <Input
                className="border-none bg-transparent shadow-none text-[25px] font-medium font-['Inter',Helvetica] h-full placeholder:text-black focus-visible:ring-0"
                placeholder="Search"
              />
            </div>
          </div>
        </div>

        {/* Image Gallery */}
        <ScrollArea className="fixed w-[1246px] h-[906px] top-[118px] left-[168px]">
          <div className="relative w-full h-[1634px]">
            {galleryImages.map((image, index) => (
              <img
                key={`gallery-image-${index}`}
                className={`absolute w-[268px] ${image.height} ${image.top} ${image.left} object-cover rounded-lg cursor-pointer hover:opacity-80 hover:scale-105 transition-all duration-300 shadow-md hover:shadow-xl`}
                alt={image.alt}
                src={image.src}
                onClick={() => handlePhotoClick(index)}
              />
            ))}
          </div>
          <ScrollBar
            orientation="vertical"
            className="w-6 bg-[#d9d9d9] rounded-[10px_10px_30px_0px]"
          />
        </ScrollArea>

        {/* Sidebar with One Piece logo and functional navigation */}
        <div className="fixed w-[116px] h-[1024px] top-0 left-0 bg-[#a8d2ec] flex flex-col items-center z-20">
          {/* One Piece Logo */}
          <div 
            className="w-[92px] h-[92px] mt-9 cursor-pointer hover:opacity-80 transition-opacity flex items-center justify-center bg-white rounded-full shadow-lg"
            onClick={() => handleNavigation('home')}
          >
            <img
              className="w-[80px] h-[80px] object-contain"
              alt="One Piece Logo"
              src="https://images.pexels.com/photos/8728380/pexels-photo-8728380.png?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
            />
          </div>

          <div className="relative w-[68px] h-[815px] mt-[74px]">
            {navigationIcons.map((item, index) => (
              <div
                key={`nav-icon-${index}`}
                className={`absolute w-[65px] h-[65px] ${item.top} left-0 flex items-center justify-center cursor-pointer hover:bg-white/20 rounded-lg transition-all duration-200 hover:scale-110 active:scale-95`}
                onClick={item.onClick}
                title={item.alt}
              >
                {item.icon}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};