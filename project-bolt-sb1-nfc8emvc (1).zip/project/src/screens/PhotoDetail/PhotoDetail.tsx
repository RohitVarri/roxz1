import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeftIcon, HeartIcon, ShareIcon, DownloadIcon, MoreHorizontalIcon } from "lucide-react";
import { Avatar, AvatarFallback } from "../../components/ui/avatar";

export const PhotoDetail = (): JSX.Element => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  // Sample photo data - in a real app, this would come from an API
  const photos = [
    {
      id: 0,
      src: "https://images.unsplash.com/photo-1526779259212-939e64788e3c?fm=jpg&q=60&w=3000",
      title: "Breathtaking Mountain Landscape",
      description: "A stunning view of snow-capped mountains during golden hour, showcasing nature's incredible beauty and serenity.",
      author: "Sarah Johnson",
      authorAvatar: "SJ",
      likes: 1247,
      saves: 892,
      tags: ["landscape", "mountains", "nature", "photography", "golden hour"]
    },
    {
      id: 1,
      src: "https://images.pexels.com/photos/1704120/pexels-photo-1704120.jpeg",
      title: "Modern Architecture Marvel",
      description: "Contemporary building design featuring clean lines and geometric patterns that create a striking visual impact.",
      author: "Michael Chen",
      authorAvatar: "MC",
      likes: 856,
      saves: 634,
      tags: ["architecture", "modern", "design", "building", "contemporary"]
    },
    {
      id: 2,
      src: "https://images.unsplash.com/photo-1545239351-1141bd82e8a6",
      title: "Cozy Interior Design",
      description: "Warm and inviting living space with carefully curated furniture and decor that creates the perfect atmosphere.",
      author: "Emma Wilson",
      authorAvatar: "EW",
      likes: 2103,
      saves: 1456,
      tags: ["interior", "design", "home", "cozy", "decor"]
    },
    {
      id: 3,
      src: "https://images.pexels.com/photos/459225/pexels-photo-459225.jpeg",
      title: "Gourmet Food Photography",
      description: "Artfully plated dish showcasing culinary excellence with vibrant colors and perfect presentation.",
      author: "David Rodriguez",
      authorAvatar: "DR",
      likes: 1789,
      saves: 923,
      tags: ["food", "photography", "gourmet", "culinary", "plating"]
    },
    {
      id: 4,
      src: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97",
      title: "Technology Innovation",
      description: "Cutting-edge technology setup featuring the latest gadgets and innovative design solutions.",
      author: "Alex Kim",
      authorAvatar: "AK",
      likes: 945,
      saves: 567,
      tags: ["technology", "innovation", "gadgets", "modern", "tech"]
    },
    {
      id: 5,
      src: "https://images.pexels.com/photos/1323550/pexels-photo-1323550.jpeg",
      title: "Fashion Forward",
      description: "Contemporary fashion styling that pushes boundaries and showcases creative expression through clothing.",
      author: "Isabella Martinez",
      authorAvatar: "IM",
      likes: 3421,
      saves: 2187,
      tags: ["fashion", "style", "clothing", "trendy", "outfit"]
    }
  ];

  const photoId = parseInt(id || "0");
  const photo = photos[photoId] || photos[0];

  const handleBack = () => {
    navigate("/");
  };

  const handleLike = () => {
    console.log("Liked photo:", photo.title);
  };

  const handleSave = () => {
    console.log("Saved photo:", photo.title);
  };

  const handleShare = () => {
    console.log("Shared photo:", photo.title);
  };

  const handleDownload = () => {
    console.log("Downloaded photo:", photo.title);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <button
              onClick={handleBack}
              className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeftIcon size={20} />
              <span className="font-medium">Back to Gallery</span>
            </button>
            
            <div className="flex items-center space-x-4">
              <button
                onClick={handleLike}
                className="flex items-center space-x-1 px-4 py-2 bg-red-50 text-red-600 rounded-full hover:bg-red-100 transition-colors"
              >
                <HeartIcon size={18} />
                <span>{photo.likes}</span>
              </button>
              
              <button
                onClick={handleSave}
                className="px-4 py-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors"
              >
                Save ({photo.saves})
              </button>
              
              <button
                onClick={handleShare}
                className="p-2 text-gray-600 hover:text-gray-900 transition-colors"
              >
                <ShareIcon size={20} />
              </button>
              
              <button
                onClick={handleDownload}
                className="p-2 text-gray-600 hover:text-gray-900 transition-colors"
              >
                <DownloadIcon size={20} />
              </button>
              
              <button className="p-2 text-gray-600 hover:text-gray-900 transition-colors">
                <MoreHorizontalIcon size={20} />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Photo */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
              <img
                src={photo.src}
                alt={photo.title}
                className="w-full h-auto max-h-[80vh] object-contain"
              />
            </div>
          </div>

          {/* Details Sidebar */}
          <div className="space-y-6">
            {/* Author Info */}
            <div className="bg-white rounded-2xl p-6 shadow-lg">
              <div className="flex items-center space-x-4 mb-4">
                <Avatar className="w-12 h-12 bg-gradient-to-r from-purple-400 to-pink-400">
                  <AvatarFallback className="text-white font-semibold">
                    {photo.authorAvatar}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-semibold text-gray-900">{photo.author}</h3>
                  <p className="text-sm text-gray-500">Photographer</p>
                </div>
              </div>
              
              <button className="w-full py-2 px-4 bg-gray-900 text-white rounded-full hover:bg-gray-800 transition-colors">
                Follow
              </button>
            </div>

            {/* Photo Details */}
            <div className="bg-white rounded-2xl p-6 shadow-lg">
              <h1 className="text-2xl font-bold text-gray-900 mb-3">
                {photo.title}
              </h1>
              
              <p className="text-gray-600 mb-6 leading-relaxed">
                {photo.description}
              </p>

              {/* Stats */}
              <div className="flex items-center space-x-6 mb-6 text-sm text-gray-500">
                <div className="flex items-center space-x-1">
                  <HeartIcon size={16} />
                  <span>{photo.likes} likes</span>
                </div>
                <div>
                  <span>{photo.saves} saves</span>
                </div>
              </div>

              {/* Tags */}
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Tags</h4>
                <div className="flex flex-wrap gap-2">
                  {photo.tags.map((tag, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm hover:bg-gray-200 cursor-pointer transition-colors"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Comments Section */}
            <div className="bg-white rounded-2xl p-6 shadow-lg">
              <h4 className="font-semibold text-gray-900 mb-4">Comments</h4>
              
              <div className="space-y-4">
                <div className="flex space-x-3">
                  <Avatar className="w-8 h-8 bg-gradient-to-r from-blue-400 to-purple-400">
                    <AvatarFallback className="text-white text-sm">JD</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm"><span className="font-semibold">John Doe</span> Amazing shot! The lighting is perfect.</p>
                    <p className="text-xs text-gray-500 mt-1">2 hours ago</p>
                  </div>
                </div>
                
                <div className="flex space-x-3">
                  <Avatar className="w-8 h-8 bg-gradient-to-r from-green-400 to-blue-400">
                    <AvatarFallback className="text-white text-sm">AS</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm"><span className="font-semibold">Anna Smith</span> This is so inspiring! 🔥</p>
                    <p className="text-xs text-gray-500 mt-1">5 hours ago</p>
                  </div>
                </div>
              </div>
              
              <div className="mt-4 pt-4 border-t">
                <div className="flex space-x-3">
                  <Avatar className="w-8 h-8 bg-gradient-to-r from-purple-400 to-pink-400">
                    <AvatarFallback className="text-white text-sm">R</AvatarFallback>
                  </Avatar>
                  <input
                    type="text"
                    placeholder="Add a comment..."
                    className="flex-1 px-3 py-2 border border-gray-200 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};