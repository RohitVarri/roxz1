import React from "react";
import { Routes, Route } from "react-router-dom";
import { Desktop } from "./screens/Desktop";
import { PhotoDetail } from "./screens/PhotoDetail";
import { Explore } from "./screens/Explore/Explore";
import { CreatePost } from "./screens/CreatePost";
import { Notifications } from "./screens/Notifications";
import { Messages } from "./screens/Messages";
import { Settings } from "./screens/Settings";

export const App = (): JSX.Element => {
  return (
    <Routes>
      <Route path="/" element={<Desktop />} />
      <Route path="/home" element={<Desktop />} />
      <Route path="/explore" element={<Explore />} />
      <Route path="/create" element={<CreatePost />} />
      <Route path="/notifications" element={<Notifications />} />
      <Route path="/messages" element={<Messages />} />
      <Route path="/settings" element={<Settings />} />
      <Route path="/photo/:id" element={<PhotoDetail />} />
    </Routes>
  );
};